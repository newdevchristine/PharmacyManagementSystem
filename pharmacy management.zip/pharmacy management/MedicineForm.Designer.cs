﻿namespace pharmacy_management
{
    partial class MedicineForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MedicineForm));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.Mednametb = new Bunifu.UI.WinForms.BunifuTextBox();
            this.Bptb = new Bunifu.UI.WinForms.BunifuTextBox();
            this.ExpireDate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.sptb = new Bunifu.UI.WinForms.BunifuTextBox();
            this.qtytb = new Bunifu.UI.WinForms.BunifuTextBox();
            this.companycb = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.MedicineGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.medicinetblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pharmacy_Management_dbDataSet = new pharmacy_management.Pharmacy_Management_dbDataSet();
            this.medicinetblTableAdapter = new pharmacy_management.Pharmacy_Management_dbDataSetTableAdapters.MedicinetblTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.MedicineGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicinetblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pharmacy_Management_dbDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.Brown;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(13, 13);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(201, 33);
            this.guna2HtmlLabel1.TabIndex = 0;
            this.guna2HtmlLabel1.Text = "Medicine Stock";
            // 
            // Mednametb
            // 
            this.Mednametb.AcceptsReturn = false;
            this.Mednametb.AcceptsTab = false;
            this.Mednametb.AnimationSpeed = 200;
            this.Mednametb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Mednametb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Mednametb.AutoSizeHeight = true;
            this.Mednametb.BackColor = System.Drawing.Color.White;
            this.Mednametb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Mednametb.BackgroundImage")));
            this.Mednametb.BorderColorActive = System.Drawing.Color.Brown;
            this.Mednametb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.Mednametb.BorderColorHover = System.Drawing.Color.IndianRed;
            this.Mednametb.BorderColorIdle = System.Drawing.Color.Silver;
            this.Mednametb.BorderRadius = 1;
            this.Mednametb.BorderThickness = 1;
            this.Mednametb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Mednametb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Mednametb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.Mednametb.DefaultText = "";
            this.Mednametb.FillColor = System.Drawing.Color.White;
            this.Mednametb.HideSelection = true;
            this.Mednametb.IconLeft = null;
            this.Mednametb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.Mednametb.IconPadding = 10;
            this.Mednametb.IconRight = null;
            this.Mednametb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.Mednametb.Lines = new string[0];
            this.Mednametb.Location = new System.Drawing.Point(13, 53);
            this.Mednametb.MaxLength = 32767;
            this.Mednametb.MinimumSize = new System.Drawing.Size(1, 1);
            this.Mednametb.Modified = false;
            this.Mednametb.Multiline = false;
            this.Mednametb.Name = "Mednametb";
            stateProperties1.BorderColor = System.Drawing.Color.Brown;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Mednametb.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.Mednametb.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.IndianRed;
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Mednametb.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Mednametb.OnIdleState = stateProperties4;
            this.Mednametb.Padding = new System.Windows.Forms.Padding(3);
            this.Mednametb.PasswordChar = '\0';
            this.Mednametb.PlaceholderForeColor = System.Drawing.Color.Brown;
            this.Mednametb.PlaceholderText = "MedicineName";
            this.Mednametb.ReadOnly = false;
            this.Mednametb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Mednametb.SelectedText = "";
            this.Mednametb.SelectionLength = 0;
            this.Mednametb.SelectionStart = 0;
            this.Mednametb.ShortcutsEnabled = true;
            this.Mednametb.Size = new System.Drawing.Size(201, 39);
            this.Mednametb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.Mednametb.TabIndex = 1;
            this.Mednametb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Mednametb.TextMarginBottom = 0;
            this.Mednametb.TextMarginLeft = 3;
            this.Mednametb.TextMarginTop = 1;
            this.Mednametb.TextPlaceholder = "MedicineName";
            this.Mednametb.UseSystemPasswordChar = false;
            this.Mednametb.WordWrap = true;
            // 
            // Bptb
            // 
            this.Bptb.AcceptsReturn = false;
            this.Bptb.AcceptsTab = false;
            this.Bptb.AnimationSpeed = 200;
            this.Bptb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Bptb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Bptb.AutoSizeHeight = true;
            this.Bptb.BackColor = System.Drawing.Color.White;
            this.Bptb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Bptb.BackgroundImage")));
            this.Bptb.BorderColorActive = System.Drawing.Color.Brown;
            this.Bptb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.Bptb.BorderColorHover = System.Drawing.Color.IndianRed;
            this.Bptb.BorderColorIdle = System.Drawing.Color.Silver;
            this.Bptb.BorderRadius = 1;
            this.Bptb.BorderThickness = 1;
            this.Bptb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Bptb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Bptb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.Bptb.DefaultText = "";
            this.Bptb.FillColor = System.Drawing.Color.White;
            this.Bptb.HideSelection = true;
            this.Bptb.IconLeft = null;
            this.Bptb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.Bptb.IconPadding = 10;
            this.Bptb.IconRight = null;
            this.Bptb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.Bptb.Lines = new string[0];
            this.Bptb.Location = new System.Drawing.Point(12, 98);
            this.Bptb.MaxLength = 32767;
            this.Bptb.MinimumSize = new System.Drawing.Size(1, 1);
            this.Bptb.Modified = false;
            this.Bptb.Multiline = false;
            this.Bptb.Name = "Bptb";
            stateProperties5.BorderColor = System.Drawing.Color.Brown;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Bptb.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.Bptb.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.IndianRed;
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Bptb.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Bptb.OnIdleState = stateProperties8;
            this.Bptb.Padding = new System.Windows.Forms.Padding(3);
            this.Bptb.PasswordChar = '\0';
            this.Bptb.PlaceholderForeColor = System.Drawing.Color.Brown;
            this.Bptb.PlaceholderText = "BuyingPrice";
            this.Bptb.ReadOnly = false;
            this.Bptb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Bptb.SelectedText = "";
            this.Bptb.SelectionLength = 0;
            this.Bptb.SelectionStart = 0;
            this.Bptb.ShortcutsEnabled = true;
            this.Bptb.Size = new System.Drawing.Size(202, 39);
            this.Bptb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.Bptb.TabIndex = 2;
            this.Bptb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Bptb.TextMarginBottom = 0;
            this.Bptb.TextMarginLeft = 3;
            this.Bptb.TextMarginTop = 1;
            this.Bptb.TextPlaceholder = "BuyingPrice";
            this.Bptb.UseSystemPasswordChar = false;
            this.Bptb.WordWrap = true;
            // 
            // ExpireDate
            // 
            this.ExpireDate.Checked = true;
            this.ExpireDate.CheckedState.Parent = this.ExpireDate;
            this.ExpireDate.FillColor = System.Drawing.Color.Brown;
            this.ExpireDate.FocusedColor = System.Drawing.Color.IndianRed;
            this.ExpireDate.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExpireDate.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ExpireDate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.ExpireDate.HoverState.Parent = this.ExpireDate;
            this.ExpireDate.Location = new System.Drawing.Point(13, 144);
            this.ExpireDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.ExpireDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.ExpireDate.Name = "ExpireDate";
            this.ExpireDate.ShadowDecoration.Parent = this.ExpireDate;
            this.ExpireDate.Size = new System.Drawing.Size(201, 36);
            this.ExpireDate.TabIndex = 3;
            this.ExpireDate.Value = new System.DateTime(2022, 1, 12, 10, 25, 43, 506);
            // 
            // sptb
            // 
            this.sptb.AcceptsReturn = false;
            this.sptb.AcceptsTab = false;
            this.sptb.AnimationSpeed = 200;
            this.sptb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.sptb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.sptb.AutoSizeHeight = true;
            this.sptb.BackColor = System.Drawing.Color.White;
            this.sptb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sptb.BackgroundImage")));
            this.sptb.BorderColorActive = System.Drawing.Color.Brown;
            this.sptb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.sptb.BorderColorHover = System.Drawing.Color.IndianRed;
            this.sptb.BorderColorIdle = System.Drawing.Color.Silver;
            this.sptb.BorderRadius = 1;
            this.sptb.BorderThickness = 1;
            this.sptb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.sptb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.sptb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.sptb.DefaultText = "";
            this.sptb.FillColor = System.Drawing.Color.White;
            this.sptb.HideSelection = true;
            this.sptb.IconLeft = null;
            this.sptb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.sptb.IconPadding = 10;
            this.sptb.IconRight = null;
            this.sptb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.sptb.Lines = new string[0];
            this.sptb.Location = new System.Drawing.Point(13, 186);
            this.sptb.MaxLength = 32767;
            this.sptb.MinimumSize = new System.Drawing.Size(1, 1);
            this.sptb.Modified = false;
            this.sptb.Multiline = false;
            this.sptb.Name = "sptb";
            stateProperties9.BorderColor = System.Drawing.Color.Brown;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sptb.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.sptb.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.IndianRed;
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sptb.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.sptb.OnIdleState = stateProperties12;
            this.sptb.Padding = new System.Windows.Forms.Padding(3);
            this.sptb.PasswordChar = '\0';
            this.sptb.PlaceholderForeColor = System.Drawing.Color.Brown;
            this.sptb.PlaceholderText = "SellingPrice";
            this.sptb.ReadOnly = false;
            this.sptb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.sptb.SelectedText = "";
            this.sptb.SelectionLength = 0;
            this.sptb.SelectionStart = 0;
            this.sptb.ShortcutsEnabled = true;
            this.sptb.Size = new System.Drawing.Size(201, 39);
            this.sptb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.sptb.TabIndex = 4;
            this.sptb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.sptb.TextMarginBottom = 0;
            this.sptb.TextMarginLeft = 3;
            this.sptb.TextMarginTop = 1;
            this.sptb.TextPlaceholder = "SellingPrice";
            this.sptb.UseSystemPasswordChar = false;
            this.sptb.WordWrap = true;
            // 
            // qtytb
            // 
            this.qtytb.AcceptsReturn = false;
            this.qtytb.AcceptsTab = false;
            this.qtytb.AnimationSpeed = 200;
            this.qtytb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.qtytb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.qtytb.AutoSizeHeight = true;
            this.qtytb.BackColor = System.Drawing.Color.White;
            this.qtytb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("qtytb.BackgroundImage")));
            this.qtytb.BorderColorActive = System.Drawing.Color.Brown;
            this.qtytb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.qtytb.BorderColorHover = System.Drawing.Color.IndianRed;
            this.qtytb.BorderColorIdle = System.Drawing.Color.Silver;
            this.qtytb.BorderRadius = 1;
            this.qtytb.BorderThickness = 1;
            this.qtytb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.qtytb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.qtytb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.qtytb.DefaultText = "";
            this.qtytb.FillColor = System.Drawing.Color.White;
            this.qtytb.HideSelection = true;
            this.qtytb.IconLeft = null;
            this.qtytb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.qtytb.IconPadding = 10;
            this.qtytb.IconRight = null;
            this.qtytb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.qtytb.Lines = new string[0];
            this.qtytb.Location = new System.Drawing.Point(13, 231);
            this.qtytb.MaxLength = 32767;
            this.qtytb.MinimumSize = new System.Drawing.Size(1, 1);
            this.qtytb.Modified = false;
            this.qtytb.Multiline = false;
            this.qtytb.Name = "qtytb";
            stateProperties13.BorderColor = System.Drawing.Color.Brown;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.qtytb.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.qtytb.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.IndianRed;
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.qtytb.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.qtytb.OnIdleState = stateProperties16;
            this.qtytb.Padding = new System.Windows.Forms.Padding(3);
            this.qtytb.PasswordChar = '\0';
            this.qtytb.PlaceholderForeColor = System.Drawing.Color.Brown;
            this.qtytb.PlaceholderText = "Quntitiy";
            this.qtytb.ReadOnly = false;
            this.qtytb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.qtytb.SelectedText = "";
            this.qtytb.SelectionLength = 0;
            this.qtytb.SelectionStart = 0;
            this.qtytb.ShortcutsEnabled = true;
            this.qtytb.Size = new System.Drawing.Size(201, 39);
            this.qtytb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.qtytb.TabIndex = 5;
            this.qtytb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.qtytb.TextMarginBottom = 0;
            this.qtytb.TextMarginLeft = 3;
            this.qtytb.TextMarginTop = 1;
            this.qtytb.TextPlaceholder = "Quntitiy";
            this.qtytb.UseSystemPasswordChar = false;
            this.qtytb.WordWrap = true;
            // 
            // companycb
            // 
            this.companycb.BackColor = System.Drawing.Color.Transparent;
            this.companycb.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.companycb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.companycb.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.companycb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.companycb.FocusedState.Parent = this.companycb;
            this.companycb.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.companycb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.companycb.HoverState.Parent = this.companycb;
            this.companycb.ItemHeight = 30;
            this.companycb.Items.AddRange(new object[] {
            "JOHNSON&JOHNSON",
            "PFIZER",
            "ROCHE",
            "NOVARTIS",
            "MERCK&CO",
            "GLAXOSMITHKLINE"});
            this.companycb.ItemsAppearance.Parent = this.companycb;
            this.companycb.Location = new System.Drawing.Point(13, 277);
            this.companycb.Name = "companycb";
            this.companycb.ShadowDecoration.Parent = this.companycb;
            this.companycb.Size = new System.Drawing.Size(201, 36);
            this.companycb.TabIndex = 6;
            // 
            // guna2Button1
            // 
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.DisabledState.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.Brown;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(13, 319);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(74, 45);
            this.guna2Button1.TabIndex = 7;
            this.guna2Button1.Text = "ADD";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // guna2Button2
            // 
            this.guna2Button2.CheckedState.Parent = this.guna2Button2;
            this.guna2Button2.CustomImages.Parent = this.guna2Button2;
            this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button2.DisabledState.Parent = this.guna2Button2;
            this.guna2Button2.FillColor = System.Drawing.Color.Brown;
            this.guna2Button2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.HoverState.Parent = this.guna2Button2;
            this.guna2Button2.Location = new System.Drawing.Point(93, 319);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.ShadowDecoration.Parent = this.guna2Button2;
            this.guna2Button2.Size = new System.Drawing.Size(121, 45);
            this.guna2Button2.TabIndex = 8;
            this.guna2Button2.Text = "UPDATE";
            this.guna2Button2.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // guna2Button3
            // 
            this.guna2Button3.CheckedState.Parent = this.guna2Button3;
            this.guna2Button3.CustomImages.Parent = this.guna2Button3;
            this.guna2Button3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button3.DisabledState.Parent = this.guna2Button3;
            this.guna2Button3.FillColor = System.Drawing.Color.Brown;
            this.guna2Button3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button3.ForeColor = System.Drawing.Color.White;
            this.guna2Button3.HoverState.Parent = this.guna2Button3;
            this.guna2Button3.Location = new System.Drawing.Point(93, 370);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.ShadowDecoration.Parent = this.guna2Button3;
            this.guna2Button3.Size = new System.Drawing.Size(121, 45);
            this.guna2Button3.TabIndex = 9;
            this.guna2Button3.Text = "DELETE";
            this.guna2Button3.Click += new System.EventHandler(this.guna2Button3_Click);
            // 
            // guna2Button4
            // 
            this.guna2Button4.CheckedState.Parent = this.guna2Button4;
            this.guna2Button4.CustomImages.Parent = this.guna2Button4;
            this.guna2Button4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button4.DisabledState.Parent = this.guna2Button4;
            this.guna2Button4.FillColor = System.Drawing.Color.Brown;
            this.guna2Button4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button4.ForeColor = System.Drawing.Color.White;
            this.guna2Button4.HoverState.Parent = this.guna2Button4;
            this.guna2Button4.Location = new System.Drawing.Point(13, 370);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.ShadowDecoration.Parent = this.guna2Button4;
            this.guna2Button4.Size = new System.Drawing.Size(74, 45);
            this.guna2Button4.TabIndex = 10;
            this.guna2Button4.Text = "Back";
            this.guna2Button4.Click += new System.EventHandler(this.guna2Button4_Click);
            // 
            // MedicineGridView
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.MedicineGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.MedicineGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.MedicineGridView.BackgroundColor = System.Drawing.Color.White;
            this.MedicineGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.MedicineGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.MedicineGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.MedicineGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.MedicineGridView.ColumnHeadersHeight = 22;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.MedicineGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.MedicineGridView.EnableHeadersVisualStyles = false;
            this.MedicineGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.MedicineGridView.Location = new System.Drawing.Point(220, 12);
            this.MedicineGridView.Name = "MedicineGridView";
            this.MedicineGridView.RowHeadersVisible = false;
            this.MedicineGridView.RowTemplate.Height = 30;
            this.MedicineGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.MedicineGridView.Size = new System.Drawing.Size(568, 426);
            this.MedicineGridView.TabIndex = 11;
            this.MedicineGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.MedicineGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.MedicineGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.MedicineGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.MedicineGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.MedicineGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.MedicineGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.MedicineGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.Brown;
            this.MedicineGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.MedicineGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MedicineGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.MedicineGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.MedicineGridView.ThemeStyle.HeaderStyle.Height = 22;
            this.MedicineGridView.ThemeStyle.ReadOnly = false;
            this.MedicineGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.MedicineGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.MedicineGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.MedicineGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.MedicineGridView.ThemeStyle.RowsStyle.Height = 30;
            this.MedicineGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.MedicineGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.MedicineGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MedicineGridView_CellContentClick);
            // 
            // medicinetblBindingSource
            // 
            this.medicinetblBindingSource.DataMember = "Medicinetbl";
            this.medicinetblBindingSource.DataSource = this.pharmacy_Management_dbDataSet;
            // 
            // pharmacy_Management_dbDataSet
            // 
            this.pharmacy_Management_dbDataSet.DataSetName = "Pharmacy_Management_dbDataSet";
            this.pharmacy_Management_dbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // medicinetblTableAdapter
            // 
            this.medicinetblTableAdapter.ClearBeforeFill = true;
            // 
            // MedicineForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.MedicineGridView);
            this.Controls.Add(this.guna2Button4);
            this.Controls.Add(this.guna2Button3);
            this.Controls.Add(this.guna2Button2);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.companycb);
            this.Controls.Add(this.qtytb);
            this.Controls.Add(this.sptb);
            this.Controls.Add(this.ExpireDate);
            this.Controls.Add(this.Bptb);
            this.Controls.Add(this.Mednametb);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MedicineForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MedicineForm";
            this.Load += new System.EventHandler(this.MedicineForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MedicineGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicinetblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pharmacy_Management_dbDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Bunifu.UI.WinForms.BunifuTextBox Mednametb;
        private Bunifu.UI.WinForms.BunifuTextBox Bptb;
        private Guna.UI2.WinForms.Guna2DateTimePicker ExpireDate;
        private Bunifu.UI.WinForms.BunifuTextBox sptb;
        private Bunifu.UI.WinForms.BunifuTextBox qtytb;
        private Guna.UI2.WinForms.Guna2ComboBox companycb;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2DataGridView MedicineGridView;
        private Pharmacy_Management_dbDataSet pharmacy_Management_dbDataSet;
        private System.Windows.Forms.BindingSource medicinetblBindingSource;
        private Pharmacy_Management_dbDataSetTableAdapters.MedicinetblTableAdapter medicinetblTableAdapter;
    }
}