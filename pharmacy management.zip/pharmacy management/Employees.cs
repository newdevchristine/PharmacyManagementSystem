﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pharmacy_management
{
    public partial class Employees : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-N3JDK48;Initial Catalog=Pharmacy_Management_db;Integrated Security=True");
        public void populate()
        {
            con.Open();
            string Myquery = "SELECT * from Empoyee_Tbl";
            SqlDataAdapter adapter = new SqlDataAdapter(Myquery, con);
            SqlCommandBuilder comd = new SqlCommandBuilder(adapter);
            var ds = new DataSet();
            adapter.Fill(ds);
            EmployeesGridView.DataSource = ds.Tables[0];
            con.Close();
        }
        public Employees()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (Empidtb.Text == "" || empsaltb.Text == "" || Empnametb.Text == "" || empgendercb.SelectedItem == null || empphonetb.Text == "" || Emppasstb.Text == "")
            {
                MessageBox.Show("Wrong Input\nFill all the filled");
            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Empoyee_Tbl VALUES('" + Empidtb.Text + "','" + Empnametb.Text + "'," + empsaltb.Text + ", '" + empgendercb.SelectedItem.ToString() + "'," + empagetb.Text + ",'" + empphonetb.Text + "','" + Emppasstb.Text + "')", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Successfully Added");
                con.Close();
                populate();
            }
        }

        private void MedicineGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Empidtb.Text = EmployeesGridView.SelectedRows[0].Cells[0].Value.ToString();
            Empnametb.Text = EmployeesGridView.SelectedRows[0].Cells[1].Value.ToString();
            empsaltb.Text = EmployeesGridView.SelectedRows[0].Cells[2].Value.ToString();
            empgendercb.SelectedItem = EmployeesGridView.SelectedRows[0].Cells[3].Value.ToString();
            empagetb.Text = EmployeesGridView.SelectedRows[0].Cells[4].Value.ToString();
            empphonetb.Text = EmployeesGridView.SelectedRows[0].Cells[5].Value.ToString();
            Emppasstb.Text = EmployeesGridView.SelectedRows[0].Cells[6].Value.ToString();
        }

        private void Employees_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'pharmacy_Management_dbDataSet1.Empoyee_Tbl' table. You can move, or remove it, as needed.
            //this.empoyee_TblTableAdapter.Fill(this.pharmacy_Management_dbDataSet1.Empoyee_Tbl);
            populate();
        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void empagetb_TextChanged(object sender, EventArgs e)
        {

        }

        private void empphonetb_TextChanged(object sender, EventArgs e)
        {

        }

        private void empgendercb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Empnametb_TextChanged(object sender, EventArgs e)
        {

        }

        private void empsaltb_TextChanged(object sender, EventArgs e)
        {

        }

        private void Empidtb_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            if (Empnametb.Text == "")
            {
                MessageBox.Show("Wrong Operation.\nClick on the medicine to be Updated");
            }
            else
            {
                con.Open();
                string Myquery = "UPDATE Empoyee_Tbl SET Empname='" + Empnametb.Text + "', Empsalary= " + empsaltb.Text + ",Empgender='" + empgendercb.SelectedItem.ToString() + "', EmpAge=" + empagetb.Text + ",EmpPhone='" + empphonetb.Text + "',EmpPassword='" + Emppasstb.Text + "' WHERE Empid='" + Empidtb.Text + "';";
                SqlCommand cmd = new SqlCommand(Myquery, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Update Successfull");
                con.Close();
                populate();
            }
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            if (Empnametb.Text == "")
            {
                MessageBox.Show("Wrong Operation.\nClick on the medicine to be Deleted");
            }
            else
            {
                con.Open();
                string query = "DELETE from Empoyee_Tbl where Empname='" + Empnametb.Text + "';";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Deleted Successfully");
                con.Close();
                populate();
            }
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            HomeForm myhome = new HomeForm();
            myhome.Show();
            this.Hide();
        }
    }
}
