﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pharmacy_management
{
    public partial class MedicineForm : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-N3JDK48;Initial Catalog=Pharmacy_Management_db;Integrated Security=True");
        public void populate()
        {
            con.Open();
            string Myquery = "SELECT * from Medicinetbl";
            SqlDataAdapter adapter = new SqlDataAdapter(Myquery, con);
            SqlCommandBuilder comd = new SqlCommandBuilder(adapter);
            var ds = new DataSet();
            adapter.Fill(ds);
            MedicineGridView.DataSource = ds.Tables[0];
            con.Close();
        }
        public MedicineForm()
        {
            InitializeComponent();
        }

        private void MedicineForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'pharmacy_Management_dbDataSet.Medicinetbl' table. You can move, or remove it, as needed.
            //this.medicinetblTableAdapter.Fill(this.pharmacy_Management_dbDataSet.Medicinetbl);
            populate();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            HomeForm myhome = new HomeForm();
            myhome.Show();
            this.Hide();
        }

        private void MedicineGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Mednametb.Text = MedicineGridView.SelectedRows[0].Cells[0].Value.ToString();
            Bptb.Text = MedicineGridView.SelectedRows[0].Cells[1].Value.ToString();
            sptb.Text = MedicineGridView.SelectedRows[0].Cells[2].Value.ToString();
            qtytb.Text = MedicineGridView.SelectedRows[0].Cells[3].Value.ToString();
            ExpireDate.Text = MedicineGridView.SelectedRows[0].Cells[4].Value.ToString();
            companycb.SelectedItem = MedicineGridView.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (Mednametb.Text == "" || sptb.Text == "" || Bptb.Text == "" || qtytb.Text == "" || companycb.SelectedItem == null)
            {
                MessageBox.Show("Missing Data!\nFill All the Information");
            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Medicinetbl VALUES('" + Mednametb.Text + "'," + Bptb.Text + "," + sptb.Text + "," + qtytb.Text + ",'" + ExpireDate.Text + "','" + companycb.SelectedItem.ToString() + "');", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Medicine Successfully Added");
                con.Close();
                populate();
            }
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            if (Mednametb.Text == "")
            {
                MessageBox.Show("Wrong Operation.\nClick on the medicine to be Updated");
            }
            else
            {
                con.Open();
                string Myquery = "UPDATE Medicinetbl SET Bprice=" + Bptb.Text + ", Sprice= " + sptb.Text + ", MedQty= " + qtytb.Text + ",ExpDate='" + ExpireDate.Text + "', Company='" + companycb.SelectedItem.ToString() + "' WHERE MedName='" + Mednametb + "';";
                SqlCommand cmd = new SqlCommand(Myquery, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Medicine Update Successfull");
                con.Close();
                populate();
            }
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            if (Mednametb.Text == "")
            {
                MessageBox.Show("Wrong Operation.\nClick on the medicine to be Deleted");
            }
            else
            {
                con.Open();
                string query = "DELETE from Medicinetbl where Medname='" + Mednametb.Text + "';";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Medicine Deleted Successfully");
                con.Close();
                populate();
            }
        }
    }
}
