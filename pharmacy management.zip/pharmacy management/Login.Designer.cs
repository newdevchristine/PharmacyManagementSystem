﻿namespace pharmacy_management
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.label1 = new System.Windows.Forms.Label();
            this.Username = new Bunifu.UI.WinForms.BunifuTextBox();
            this.Password = new Bunifu.UI.WinForms.BunifuTextBox();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Brown;
            this.label1.Location = new System.Drawing.Point(82, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Login";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Username
            // 
            this.Username.AcceptsReturn = false;
            this.Username.AcceptsTab = false;
            this.Username.AnimationSpeed = 200;
            this.Username.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Username.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Username.AutoSizeHeight = true;
            this.Username.BackColor = System.Drawing.Color.White;
            this.Username.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Username.BackgroundImage")));
            this.Username.BorderColorActive = System.Drawing.Color.Brown;
            this.Username.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.Username.BorderColorHover = System.Drawing.Color.IndianRed;
            this.Username.BorderColorIdle = System.Drawing.Color.Silver;
            this.Username.BorderRadius = 1;
            this.Username.BorderThickness = 1;
            this.Username.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Username.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Username.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.Username.DefaultText = "";
            this.Username.FillColor = System.Drawing.Color.White;
            this.Username.HideSelection = true;
            this.Username.IconLeft = null;
            this.Username.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.Username.IconPadding = 10;
            this.Username.IconRight = null;
            this.Username.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.Username.Lines = new string[0];
            this.Username.Location = new System.Drawing.Point(13, 73);
            this.Username.MaxLength = 32767;
            this.Username.MinimumSize = new System.Drawing.Size(1, 1);
            this.Username.Modified = false;
            this.Username.Multiline = false;
            this.Username.Name = "Username";
            stateProperties1.BorderColor = System.Drawing.Color.Brown;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Username.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.Username.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.IndianRed;
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Username.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Username.OnIdleState = stateProperties4;
            this.Username.Padding = new System.Windows.Forms.Padding(3);
            this.Username.PasswordChar = '\0';
            this.Username.PlaceholderForeColor = System.Drawing.Color.Brown;
            this.Username.PlaceholderText = "Username";
            this.Username.ReadOnly = false;
            this.Username.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Username.SelectedText = "";
            this.Username.SelectionLength = 0;
            this.Username.SelectionStart = 0;
            this.Username.ShortcutsEnabled = true;
            this.Username.Size = new System.Drawing.Size(260, 39);
            this.Username.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.Username.TabIndex = 1;
            this.Username.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Username.TextMarginBottom = 0;
            this.Username.TextMarginLeft = 3;
            this.Username.TextMarginTop = 1;
            this.Username.TextPlaceholder = "Username";
            this.Username.UseSystemPasswordChar = false;
            this.Username.WordWrap = true;
            // 
            // Password
            // 
            this.Password.AcceptsReturn = false;
            this.Password.AcceptsTab = false;
            this.Password.AnimationSpeed = 200;
            this.Password.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Password.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Password.AutoSizeHeight = true;
            this.Password.BackColor = System.Drawing.Color.White;
            this.Password.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Password.BackgroundImage")));
            this.Password.BorderColorActive = System.Drawing.Color.Brown;
            this.Password.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.Password.BorderColorHover = System.Drawing.Color.IndianRed;
            this.Password.BorderColorIdle = System.Drawing.Color.Silver;
            this.Password.BorderRadius = 1;
            this.Password.BorderThickness = 1;
            this.Password.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Password.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Password.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.Password.DefaultText = "";
            this.Password.FillColor = System.Drawing.Color.White;
            this.Password.HideSelection = true;
            this.Password.IconLeft = null;
            this.Password.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.Password.IconPadding = 10;
            this.Password.IconRight = null;
            this.Password.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.Password.Lines = new string[0];
            this.Password.Location = new System.Drawing.Point(12, 118);
            this.Password.MaxLength = 32767;
            this.Password.MinimumSize = new System.Drawing.Size(1, 1);
            this.Password.Modified = false;
            this.Password.Multiline = false;
            this.Password.Name = "Password";
            stateProperties5.BorderColor = System.Drawing.Color.Brown;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Password.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.Password.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.IndianRed;
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Password.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Password.OnIdleState = stateProperties8;
            this.Password.Padding = new System.Windows.Forms.Padding(3);
            this.Password.PasswordChar = '●';
            this.Password.PlaceholderForeColor = System.Drawing.Color.Brown;
            this.Password.PlaceholderText = "Password";
            this.Password.ReadOnly = false;
            this.Password.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Password.SelectedText = "";
            this.Password.SelectionLength = 0;
            this.Password.SelectionStart = 0;
            this.Password.ShortcutsEnabled = true;
            this.Password.Size = new System.Drawing.Size(260, 39);
            this.Password.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.Password.TabIndex = 2;
            this.Password.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Password.TextMarginBottom = 0;
            this.Password.TextMarginLeft = 3;
            this.Password.TextMarginTop = 1;
            this.Password.TextPlaceholder = "Password";
            this.Password.UseSystemPasswordChar = true;
            this.Password.WordWrap = true;
            // 
            // guna2Button1
            // 
            this.guna2Button1.Animated = true;
            this.guna2Button1.BorderRadius = 16;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.DisabledState.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.Brown;
            this.guna2Button1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.FillColor = System.Drawing.Color.IndianRed;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(12, 236);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(259, 45);
            this.guna2Button1.TabIndex = 3;
            this.guna2Button1.Text = "Login";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(285, 293);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private Bunifu.UI.WinForms.BunifuTextBox Username;
        private Bunifu.UI.WinForms.BunifuTextBox Password;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
    }
}