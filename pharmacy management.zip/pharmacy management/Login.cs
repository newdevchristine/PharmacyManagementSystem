﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pharmacy_management
{
    public partial class Login : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-N3JDK48;Initial Catalog=Pharmacy_Management_db;Integrated Security=True");
        HomeForm myhome = new HomeForm();
        public Login()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            //if (Username.Text=="Admin"&&Password.Text=="admin")
            //{
            //    myhome.Show();
            //    this.Hide();
            //}
            //else
            //{
            //    MessageBox.Show("Wrong Username or Password!");
            //}
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("SELECT COUNT(*) from Empoyee_Tbl where Empname = '" + Username.Text + "' and EmpPassword = '" + Password.Text + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString()=="1" || Username.Text == "Admin" && Password.Text == "admin")
            {
                myhome.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Wrong Wrong Username or Password!");
            }
            con.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
