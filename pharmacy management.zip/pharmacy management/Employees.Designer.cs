﻿namespace pharmacy_management
{
    partial class Employees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Employees));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.empgendercb = new Guna.UI2.WinForms.Guna2ComboBox();
            this.empphonetb = new Bunifu.UI.WinForms.BunifuTextBox();
            this.Empnametb = new Bunifu.UI.WinForms.BunifuTextBox();
            this.empsaltb = new Bunifu.UI.WinForms.BunifuTextBox();
            this.Empidtb = new Bunifu.UI.WinForms.BunifuTextBox();
            this.empagetb = new Bunifu.UI.WinForms.BunifuTextBox();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.EmployeesGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.pharmacy_Management_dbDataSet1 = new pharmacy_management.Pharmacy_Management_dbDataSet1();
            this.empoyeeTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.empoyee_TblTableAdapter = new pharmacy_management.Pharmacy_Management_dbDataSet1TableAdapters.Empoyee_TblTableAdapter();
            this.Emppasstb = new Bunifu.UI.WinForms.BunifuTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.EmployeesGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pharmacy_Management_dbDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.empoyeeTblBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.Brown;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(12, 12);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(146, 33);
            this.guna2HtmlLabel1.TabIndex = 1;
            this.guna2HtmlLabel1.Text = "Employees";
            this.guna2HtmlLabel1.Click += new System.EventHandler(this.guna2HtmlLabel1_Click);
            // 
            // empgendercb
            // 
            this.empgendercb.BackColor = System.Drawing.Color.Transparent;
            this.empgendercb.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.empgendercb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.empgendercb.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.empgendercb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.empgendercb.FocusedState.Parent = this.empgendercb;
            this.empgendercb.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.empgendercb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.empgendercb.HoverState.Parent = this.empgendercb;
            this.empgendercb.ItemHeight = 30;
            this.empgendercb.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.empgendercb.ItemsAppearance.Parent = this.empgendercb;
            this.empgendercb.Location = new System.Drawing.Point(9, 184);
            this.empgendercb.Name = "empgendercb";
            this.empgendercb.ShadowDecoration.Parent = this.empgendercb;
            this.empgendercb.Size = new System.Drawing.Size(179, 36);
            this.empgendercb.TabIndex = 11;
            this.empgendercb.SelectedIndexChanged += new System.EventHandler(this.empgendercb_SelectedIndexChanged);
            // 
            // empphonetb
            // 
            this.empphonetb.AcceptsReturn = false;
            this.empphonetb.AcceptsTab = false;
            this.empphonetb.AnimationSpeed = 200;
            this.empphonetb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.empphonetb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.empphonetb.AutoSizeHeight = true;
            this.empphonetb.BackColor = System.Drawing.Color.White;
            this.empphonetb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("empphonetb.BackgroundImage")));
            this.empphonetb.BorderColorActive = System.Drawing.Color.Brown;
            this.empphonetb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.empphonetb.BorderColorHover = System.Drawing.Color.IndianRed;
            this.empphonetb.BorderColorIdle = System.Drawing.Color.Silver;
            this.empphonetb.BorderRadius = 1;
            this.empphonetb.BorderThickness = 1;
            this.empphonetb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.empphonetb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.empphonetb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.empphonetb.DefaultText = "";
            this.empphonetb.FillColor = System.Drawing.Color.White;
            this.empphonetb.HideSelection = true;
            this.empphonetb.IconLeft = null;
            this.empphonetb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.empphonetb.IconPadding = 10;
            this.empphonetb.IconRight = null;
            this.empphonetb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.empphonetb.Lines = new string[0];
            this.empphonetb.Location = new System.Drawing.Point(10, 226);
            this.empphonetb.MaxLength = 32767;
            this.empphonetb.MinimumSize = new System.Drawing.Size(1, 1);
            this.empphonetb.Modified = false;
            this.empphonetb.Multiline = false;
            this.empphonetb.Name = "empphonetb";
            stateProperties1.BorderColor = System.Drawing.Color.Brown;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.empphonetb.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.empphonetb.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.IndianRed;
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.empphonetb.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.empphonetb.OnIdleState = stateProperties4;
            this.empphonetb.Padding = new System.Windows.Forms.Padding(3);
            this.empphonetb.PasswordChar = '\0';
            this.empphonetb.PlaceholderForeColor = System.Drawing.Color.Brown;
            this.empphonetb.PlaceholderText = "Phone Number";
            this.empphonetb.ReadOnly = false;
            this.empphonetb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.empphonetb.SelectedText = "";
            this.empphonetb.SelectionLength = 0;
            this.empphonetb.SelectionStart = 0;
            this.empphonetb.ShortcutsEnabled = true;
            this.empphonetb.Size = new System.Drawing.Size(179, 39);
            this.empphonetb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.empphonetb.TabIndex = 10;
            this.empphonetb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.empphonetb.TextMarginBottom = 0;
            this.empphonetb.TextMarginLeft = 3;
            this.empphonetb.TextMarginTop = 1;
            this.empphonetb.TextPlaceholder = "Phone Number";
            this.empphonetb.UseSystemPasswordChar = false;
            this.empphonetb.WordWrap = true;
            this.empphonetb.TextChanged += new System.EventHandler(this.empphonetb_TextChanged);
            // 
            // Empnametb
            // 
            this.Empnametb.AcceptsReturn = false;
            this.Empnametb.AcceptsTab = false;
            this.Empnametb.AnimationSpeed = 200;
            this.Empnametb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Empnametb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Empnametb.AutoSizeHeight = true;
            this.Empnametb.BackColor = System.Drawing.Color.White;
            this.Empnametb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Empnametb.BackgroundImage")));
            this.Empnametb.BorderColorActive = System.Drawing.Color.Brown;
            this.Empnametb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.Empnametb.BorderColorHover = System.Drawing.Color.IndianRed;
            this.Empnametb.BorderColorIdle = System.Drawing.Color.Silver;
            this.Empnametb.BorderRadius = 1;
            this.Empnametb.BorderThickness = 1;
            this.Empnametb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Empnametb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Empnametb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.Empnametb.DefaultText = "";
            this.Empnametb.FillColor = System.Drawing.Color.White;
            this.Empnametb.HideSelection = true;
            this.Empnametb.IconLeft = null;
            this.Empnametb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.Empnametb.IconPadding = 10;
            this.Empnametb.IconRight = null;
            this.Empnametb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.Empnametb.Lines = new string[0];
            this.Empnametb.Location = new System.Drawing.Point(10, 93);
            this.Empnametb.MaxLength = 32767;
            this.Empnametb.MinimumSize = new System.Drawing.Size(1, 1);
            this.Empnametb.Modified = false;
            this.Empnametb.Multiline = false;
            this.Empnametb.Name = "Empnametb";
            stateProperties5.BorderColor = System.Drawing.Color.Brown;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Empnametb.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.Empnametb.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.IndianRed;
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Empnametb.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Empnametb.OnIdleState = stateProperties8;
            this.Empnametb.Padding = new System.Windows.Forms.Padding(3);
            this.Empnametb.PasswordChar = '\0';
            this.Empnametb.PlaceholderForeColor = System.Drawing.Color.Brown;
            this.Empnametb.PlaceholderText = "Employee Name";
            this.Empnametb.ReadOnly = false;
            this.Empnametb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Empnametb.SelectedText = "";
            this.Empnametb.SelectionLength = 0;
            this.Empnametb.SelectionStart = 0;
            this.Empnametb.ShortcutsEnabled = true;
            this.Empnametb.Size = new System.Drawing.Size(179, 39);
            this.Empnametb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.Empnametb.TabIndex = 9;
            this.Empnametb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Empnametb.TextMarginBottom = 0;
            this.Empnametb.TextMarginLeft = 3;
            this.Empnametb.TextMarginTop = 1;
            this.Empnametb.TextPlaceholder = "Employee Name";
            this.Empnametb.UseSystemPasswordChar = false;
            this.Empnametb.WordWrap = true;
            this.Empnametb.TextChanged += new System.EventHandler(this.Empnametb_TextChanged);
            // 
            // empsaltb
            // 
            this.empsaltb.AcceptsReturn = false;
            this.empsaltb.AcceptsTab = false;
            this.empsaltb.AnimationSpeed = 200;
            this.empsaltb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.empsaltb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.empsaltb.AutoSizeHeight = true;
            this.empsaltb.BackColor = System.Drawing.Color.White;
            this.empsaltb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("empsaltb.BackgroundImage")));
            this.empsaltb.BorderColorActive = System.Drawing.Color.Brown;
            this.empsaltb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.empsaltb.BorderColorHover = System.Drawing.Color.IndianRed;
            this.empsaltb.BorderColorIdle = System.Drawing.Color.Silver;
            this.empsaltb.BorderRadius = 1;
            this.empsaltb.BorderThickness = 1;
            this.empsaltb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.empsaltb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.empsaltb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.empsaltb.DefaultText = "";
            this.empsaltb.FillColor = System.Drawing.Color.White;
            this.empsaltb.HideSelection = true;
            this.empsaltb.IconLeft = null;
            this.empsaltb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.empsaltb.IconPadding = 10;
            this.empsaltb.IconRight = null;
            this.empsaltb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.empsaltb.Lines = new string[0];
            this.empsaltb.Location = new System.Drawing.Point(8, 139);
            this.empsaltb.MaxLength = 32767;
            this.empsaltb.MinimumSize = new System.Drawing.Size(1, 1);
            this.empsaltb.Modified = false;
            this.empsaltb.Multiline = false;
            this.empsaltb.Name = "empsaltb";
            stateProperties9.BorderColor = System.Drawing.Color.Brown;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.empsaltb.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.empsaltb.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.IndianRed;
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.empsaltb.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.empsaltb.OnIdleState = stateProperties12;
            this.empsaltb.Padding = new System.Windows.Forms.Padding(3);
            this.empsaltb.PasswordChar = '\0';
            this.empsaltb.PlaceholderForeColor = System.Drawing.Color.Brown;
            this.empsaltb.PlaceholderText = "Salary";
            this.empsaltb.ReadOnly = false;
            this.empsaltb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.empsaltb.SelectedText = "";
            this.empsaltb.SelectionLength = 0;
            this.empsaltb.SelectionStart = 0;
            this.empsaltb.ShortcutsEnabled = true;
            this.empsaltb.Size = new System.Drawing.Size(180, 39);
            this.empsaltb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.empsaltb.TabIndex = 8;
            this.empsaltb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.empsaltb.TextMarginBottom = 0;
            this.empsaltb.TextMarginLeft = 3;
            this.empsaltb.TextMarginTop = 1;
            this.empsaltb.TextPlaceholder = "Salary";
            this.empsaltb.UseSystemPasswordChar = false;
            this.empsaltb.WordWrap = true;
            this.empsaltb.TextChanged += new System.EventHandler(this.empsaltb_TextChanged);
            // 
            // Empidtb
            // 
            this.Empidtb.AcceptsReturn = false;
            this.Empidtb.AcceptsTab = false;
            this.Empidtb.AnimationSpeed = 200;
            this.Empidtb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Empidtb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Empidtb.AutoSizeHeight = true;
            this.Empidtb.BackColor = System.Drawing.Color.White;
            this.Empidtb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Empidtb.BackgroundImage")));
            this.Empidtb.BorderColorActive = System.Drawing.Color.Brown;
            this.Empidtb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.Empidtb.BorderColorHover = System.Drawing.Color.IndianRed;
            this.Empidtb.BorderColorIdle = System.Drawing.Color.Silver;
            this.Empidtb.BorderRadius = 1;
            this.Empidtb.BorderThickness = 1;
            this.Empidtb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Empidtb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Empidtb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.Empidtb.DefaultText = "";
            this.Empidtb.FillColor = System.Drawing.Color.White;
            this.Empidtb.HideSelection = true;
            this.Empidtb.IconLeft = null;
            this.Empidtb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.Empidtb.IconPadding = 10;
            this.Empidtb.IconRight = null;
            this.Empidtb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.Empidtb.Lines = new string[0];
            this.Empidtb.Location = new System.Drawing.Point(10, 48);
            this.Empidtb.MaxLength = 32767;
            this.Empidtb.MinimumSize = new System.Drawing.Size(1, 1);
            this.Empidtb.Modified = false;
            this.Empidtb.Multiline = false;
            this.Empidtb.Name = "Empidtb";
            stateProperties13.BorderColor = System.Drawing.Color.Brown;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Empidtb.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.Empidtb.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.IndianRed;
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Empidtb.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Empidtb.OnIdleState = stateProperties16;
            this.Empidtb.Padding = new System.Windows.Forms.Padding(3);
            this.Empidtb.PasswordChar = '\0';
            this.Empidtb.PlaceholderForeColor = System.Drawing.Color.Brown;
            this.Empidtb.PlaceholderText = "Epmloyee Id";
            this.Empidtb.ReadOnly = false;
            this.Empidtb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Empidtb.SelectedText = "";
            this.Empidtb.SelectionLength = 0;
            this.Empidtb.SelectionStart = 0;
            this.Empidtb.ShortcutsEnabled = true;
            this.Empidtb.Size = new System.Drawing.Size(179, 39);
            this.Empidtb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.Empidtb.TabIndex = 7;
            this.Empidtb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Empidtb.TextMarginBottom = 0;
            this.Empidtb.TextMarginLeft = 3;
            this.Empidtb.TextMarginTop = 1;
            this.Empidtb.TextPlaceholder = "Epmloyee Id";
            this.Empidtb.UseSystemPasswordChar = false;
            this.Empidtb.WordWrap = true;
            this.Empidtb.TextChanged += new System.EventHandler(this.Empidtb_TextChanged);
            // 
            // empagetb
            // 
            this.empagetb.AcceptsReturn = false;
            this.empagetb.AcceptsTab = false;
            this.empagetb.AnimationSpeed = 200;
            this.empagetb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.empagetb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.empagetb.AutoSizeHeight = true;
            this.empagetb.BackColor = System.Drawing.Color.White;
            this.empagetb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("empagetb.BackgroundImage")));
            this.empagetb.BorderColorActive = System.Drawing.Color.Brown;
            this.empagetb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.empagetb.BorderColorHover = System.Drawing.Color.IndianRed;
            this.empagetb.BorderColorIdle = System.Drawing.Color.Silver;
            this.empagetb.BorderRadius = 1;
            this.empagetb.BorderThickness = 1;
            this.empagetb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.empagetb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.empagetb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.empagetb.DefaultText = "";
            this.empagetb.FillColor = System.Drawing.Color.White;
            this.empagetb.HideSelection = true;
            this.empagetb.IconLeft = null;
            this.empagetb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.empagetb.IconPadding = 10;
            this.empagetb.IconRight = null;
            this.empagetb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.empagetb.Lines = new string[0];
            this.empagetb.Location = new System.Drawing.Point(10, 271);
            this.empagetb.MaxLength = 32767;
            this.empagetb.MinimumSize = new System.Drawing.Size(1, 1);
            this.empagetb.Modified = false;
            this.empagetb.Multiline = false;
            this.empagetb.Name = "empagetb";
            stateProperties17.BorderColor = System.Drawing.Color.Brown;
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.empagetb.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.empagetb.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = System.Drawing.Color.IndianRed;
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.empagetb.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.Silver;
            stateProperties20.FillColor = System.Drawing.Color.White;
            stateProperties20.ForeColor = System.Drawing.Color.Empty;
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.empagetb.OnIdleState = stateProperties20;
            this.empagetb.Padding = new System.Windows.Forms.Padding(3);
            this.empagetb.PasswordChar = '\0';
            this.empagetb.PlaceholderForeColor = System.Drawing.Color.Brown;
            this.empagetb.PlaceholderText = "Employee Age";
            this.empagetb.ReadOnly = false;
            this.empagetb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.empagetb.SelectedText = "";
            this.empagetb.SelectionLength = 0;
            this.empagetb.SelectionStart = 0;
            this.empagetb.ShortcutsEnabled = true;
            this.empagetb.Size = new System.Drawing.Size(179, 39);
            this.empagetb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.empagetb.TabIndex = 12;
            this.empagetb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.empagetb.TextMarginBottom = 0;
            this.empagetb.TextMarginLeft = 3;
            this.empagetb.TextMarginTop = 1;
            this.empagetb.TextPlaceholder = "Employee Age";
            this.empagetb.UseSystemPasswordChar = false;
            this.empagetb.WordWrap = true;
            this.empagetb.TextChanged += new System.EventHandler(this.empagetb_TextChanged);
            // 
            // guna2Button4
            // 
            this.guna2Button4.CheckedState.Parent = this.guna2Button4;
            this.guna2Button4.CustomImages.Parent = this.guna2Button4;
            this.guna2Button4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button4.DisabledState.Parent = this.guna2Button4;
            this.guna2Button4.FillColor = System.Drawing.Color.Brown;
            this.guna2Button4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button4.ForeColor = System.Drawing.Color.White;
            this.guna2Button4.HoverState.Parent = this.guna2Button4;
            this.guna2Button4.Location = new System.Drawing.Point(11, 403);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.ShadowDecoration.Parent = this.guna2Button4;
            this.guna2Button4.Size = new System.Drawing.Size(74, 35);
            this.guna2Button4.TabIndex = 16;
            this.guna2Button4.Text = "Back";
            this.guna2Button4.Click += new System.EventHandler(this.guna2Button4_Click);
            // 
            // guna2Button3
            // 
            this.guna2Button3.CheckedState.Parent = this.guna2Button3;
            this.guna2Button3.CustomImages.Parent = this.guna2Button3;
            this.guna2Button3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button3.DisabledState.Parent = this.guna2Button3;
            this.guna2Button3.FillColor = System.Drawing.Color.Brown;
            this.guna2Button3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button3.ForeColor = System.Drawing.Color.White;
            this.guna2Button3.HoverState.Parent = this.guna2Button3;
            this.guna2Button3.Location = new System.Drawing.Point(91, 403);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.ShadowDecoration.Parent = this.guna2Button3;
            this.guna2Button3.Size = new System.Drawing.Size(97, 35);
            this.guna2Button3.TabIndex = 15;
            this.guna2Button3.Text = "DELETE";
            this.guna2Button3.Click += new System.EventHandler(this.guna2Button3_Click);
            // 
            // guna2Button2
            // 
            this.guna2Button2.CheckedState.Parent = this.guna2Button2;
            this.guna2Button2.CustomImages.Parent = this.guna2Button2;
            this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button2.DisabledState.Parent = this.guna2Button2;
            this.guna2Button2.FillColor = System.Drawing.Color.Brown;
            this.guna2Button2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.HoverState.Parent = this.guna2Button2;
            this.guna2Button2.Location = new System.Drawing.Point(91, 362);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.ShadowDecoration.Parent = this.guna2Button2;
            this.guna2Button2.Size = new System.Drawing.Size(97, 35);
            this.guna2Button2.TabIndex = 14;
            this.guna2Button2.Text = "UPDATE";
            this.guna2Button2.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // guna2Button1
            // 
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.DisabledState.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.Brown;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(11, 362);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(74, 35);
            this.guna2Button1.TabIndex = 13;
            this.guna2Button1.Text = "ADD";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // EmployeesGridView
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.EmployeesGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.EmployeesGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.EmployeesGridView.BackgroundColor = System.Drawing.Color.White;
            this.EmployeesGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EmployeesGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.EmployeesGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.EmployeesGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.EmployeesGridView.ColumnHeadersHeight = 22;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.EmployeesGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.EmployeesGridView.EnableHeadersVisualStyles = false;
            this.EmployeesGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.EmployeesGridView.Location = new System.Drawing.Point(195, 12);
            this.EmployeesGridView.Name = "EmployeesGridView";
            this.EmployeesGridView.RowHeadersVisible = false;
            this.EmployeesGridView.RowTemplate.Height = 30;
            this.EmployeesGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.EmployeesGridView.Size = new System.Drawing.Size(679, 426);
            this.EmployeesGridView.TabIndex = 17;
            this.EmployeesGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.EmployeesGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.EmployeesGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.EmployeesGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.EmployeesGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.EmployeesGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.EmployeesGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.EmployeesGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.Brown;
            this.EmployeesGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.EmployeesGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeesGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.EmployeesGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.EmployeesGridView.ThemeStyle.HeaderStyle.Height = 22;
            this.EmployeesGridView.ThemeStyle.ReadOnly = false;
            this.EmployeesGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.EmployeesGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.EmployeesGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.EmployeesGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.EmployeesGridView.ThemeStyle.RowsStyle.Height = 30;
            this.EmployeesGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.EmployeesGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.EmployeesGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MedicineGridView_CellContentClick);
            // 
            // pharmacy_Management_dbDataSet1
            // 
            this.pharmacy_Management_dbDataSet1.DataSetName = "Pharmacy_Management_dbDataSet1";
            this.pharmacy_Management_dbDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // empoyeeTblBindingSource
            // 
            this.empoyeeTblBindingSource.DataMember = "Empoyee_Tbl";
            this.empoyeeTblBindingSource.DataSource = this.pharmacy_Management_dbDataSet1;
            // 
            // empoyee_TblTableAdapter
            // 
            this.empoyee_TblTableAdapter.ClearBeforeFill = true;
            // 
            // Emppasstb
            // 
            this.Emppasstb.AcceptsReturn = false;
            this.Emppasstb.AcceptsTab = false;
            this.Emppasstb.AnimationSpeed = 200;
            this.Emppasstb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Emppasstb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Emppasstb.AutoSizeHeight = true;
            this.Emppasstb.BackColor = System.Drawing.Color.White;
            this.Emppasstb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Emppasstb.BackgroundImage")));
            this.Emppasstb.BorderColorActive = System.Drawing.Color.Brown;
            this.Emppasstb.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.Emppasstb.BorderColorHover = System.Drawing.Color.IndianRed;
            this.Emppasstb.BorderColorIdle = System.Drawing.Color.Silver;
            this.Emppasstb.BorderRadius = 1;
            this.Emppasstb.BorderThickness = 1;
            this.Emppasstb.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Emppasstb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Emppasstb.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.Emppasstb.DefaultText = "";
            this.Emppasstb.FillColor = System.Drawing.Color.White;
            this.Emppasstb.HideSelection = true;
            this.Emppasstb.IconLeft = null;
            this.Emppasstb.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.Emppasstb.IconPadding = 10;
            this.Emppasstb.IconRight = null;
            this.Emppasstb.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.Emppasstb.Lines = new string[0];
            this.Emppasstb.Location = new System.Drawing.Point(9, 316);
            this.Emppasstb.MaxLength = 32767;
            this.Emppasstb.MinimumSize = new System.Drawing.Size(1, 1);
            this.Emppasstb.Modified = false;
            this.Emppasstb.Multiline = false;
            this.Emppasstb.Name = "Emppasstb";
            stateProperties21.BorderColor = System.Drawing.Color.Brown;
            stateProperties21.FillColor = System.Drawing.Color.Empty;
            stateProperties21.ForeColor = System.Drawing.Color.Empty;
            stateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Emppasstb.OnActiveState = stateProperties21;
            stateProperties22.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties22.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties22.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.Emppasstb.OnDisabledState = stateProperties22;
            stateProperties23.BorderColor = System.Drawing.Color.IndianRed;
            stateProperties23.FillColor = System.Drawing.Color.Empty;
            stateProperties23.ForeColor = System.Drawing.Color.Empty;
            stateProperties23.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Emppasstb.OnHoverState = stateProperties23;
            stateProperties24.BorderColor = System.Drawing.Color.Silver;
            stateProperties24.FillColor = System.Drawing.Color.White;
            stateProperties24.ForeColor = System.Drawing.Color.Empty;
            stateProperties24.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.Emppasstb.OnIdleState = stateProperties24;
            this.Emppasstb.Padding = new System.Windows.Forms.Padding(3);
            this.Emppasstb.PasswordChar = '\0';
            this.Emppasstb.PlaceholderForeColor = System.Drawing.Color.Brown;
            this.Emppasstb.PlaceholderText = "Employee Password";
            this.Emppasstb.ReadOnly = false;
            this.Emppasstb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Emppasstb.SelectedText = "";
            this.Emppasstb.SelectionLength = 0;
            this.Emppasstb.SelectionStart = 0;
            this.Emppasstb.ShortcutsEnabled = true;
            this.Emppasstb.Size = new System.Drawing.Size(179, 39);
            this.Emppasstb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            this.Emppasstb.TabIndex = 18;
            this.Emppasstb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Emppasstb.TextMarginBottom = 0;
            this.Emppasstb.TextMarginLeft = 3;
            this.Emppasstb.TextMarginTop = 1;
            this.Emppasstb.TextPlaceholder = "Employee Password";
            this.Emppasstb.UseSystemPasswordChar = false;
            this.Emppasstb.WordWrap = true;
            this.Emppasstb.TextChanged += new System.EventHandler(this.bunifuTextBox1_TextChanged);
            // 
            // Employees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(886, 450);
            this.Controls.Add(this.Emppasstb);
            this.Controls.Add(this.EmployeesGridView);
            this.Controls.Add(this.guna2Button4);
            this.Controls.Add(this.guna2Button3);
            this.Controls.Add(this.guna2Button2);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.empagetb);
            this.Controls.Add(this.empgendercb);
            this.Controls.Add(this.empphonetb);
            this.Controls.Add(this.Empnametb);
            this.Controls.Add(this.empsaltb);
            this.Controls.Add(this.Empidtb);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Employees";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employees";
            this.Load += new System.EventHandler(this.Employees_Load);
            ((System.ComponentModel.ISupportInitialize)(this.EmployeesGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pharmacy_Management_dbDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.empoyeeTblBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2ComboBox empgendercb;
        private Bunifu.UI.WinForms.BunifuTextBox empphonetb;
        private Bunifu.UI.WinForms.BunifuTextBox Empnametb;
        private Bunifu.UI.WinForms.BunifuTextBox empsaltb;
        private Bunifu.UI.WinForms.BunifuTextBox Empidtb;
        private Bunifu.UI.WinForms.BunifuTextBox empagetb;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2DataGridView EmployeesGridView;
        private Pharmacy_Management_dbDataSet1 pharmacy_Management_dbDataSet1;
        private System.Windows.Forms.BindingSource empoyeeTblBindingSource;
        private Pharmacy_Management_dbDataSet1TableAdapters.Empoyee_TblTableAdapter empoyee_TblTableAdapter;
        private Bunifu.UI.WinForms.BunifuTextBox Emppasstb;
    }
}